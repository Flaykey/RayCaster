#pragma once
class Line
{
public:
    Line(int x1, int y1, int x2, int y2);
    int x1;
    int y1;
    int x2;
    int y2;
    void draw();
};
